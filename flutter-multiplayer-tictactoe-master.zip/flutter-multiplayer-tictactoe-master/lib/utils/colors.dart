import 'package:flutter/material.dart';

const bgColor = Color.fromRGBO(16, 13, 34, 1);
