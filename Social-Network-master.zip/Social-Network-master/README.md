![logo-transparent](https://user-images.githubusercontent.com/56977388/180226746-a993ceb9-a886-4fc3-9b36-dbcb6cc93d41.png)


A social networking Django application (similar to Twitter) written in Python, HTML, CSS &amp; JavaScript.

#### Project Video: [Watch on Youtube](https://www.youtube.com/watch?v=d4_sidaZUZY)


<img width="954" alt="socialnetwork" src="https://user-images.githubusercontent.com/56977388/180219431-961e5777-28cf-470e-bd42-1c91fa176642.png">
